This folder contains Jasmine test specifications which can only be tested both using nodejs

